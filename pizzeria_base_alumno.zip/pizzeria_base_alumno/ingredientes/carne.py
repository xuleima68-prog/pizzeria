from ingredientes.ingrediente import Ingrediente

class Carne(Ingrediente):
    """TODO: completar clase Carne"""
    def __init__(self, nombre):
        super().__init__(nombre, "🥩", 200)
